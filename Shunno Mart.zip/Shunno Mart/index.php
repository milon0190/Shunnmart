<?php
// index.php (Homepage)

// Always start with the config file to load functions and DB connection.
require_once 'common/config.php';

// --- Fetch Data for Display ---
$categories = [];
$products = [];

if ($conn && !$conn->connect_error) {
    // Fetch top categories
    $cat_result = $conn->query("SELECT id, name, image FROM categories WHERE parent_id IS NULL ORDER BY name ASC LIMIT 10");
    if ($cat_result) {
        while ($row = $cat_result->fetch_assoc()) {
            $categories[] = $row;
        }
    }

    // Fetch featured products
    $prod_result = $conn->query("SELECT id, name, price, image FROM products ORDER BY created_at DESC LIMIT 8");
    if ($prod_result) {
        while ($row = $prod_result->fetch_assoc()) {
            $products[] = $row;
        }
    }
}

// Include HTML header and sidebar
include 'common/header.php';
include 'common/sidebar.php';
?>

<main class="p-4">
    <!-- Search Bar -->
    <div class="relative mb-6">
        <input type="text" placeholder="Search for products..." class="w-full pl-10 pr-4 py-3 rounded-full bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-300">
        <i class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
    </div>

    <!-- Categories Section -->
    <section class="mb-8">
        <h2 class="text-xl font-bold mb-3 text-slate-800">Categories</h2>
        <div class="flex space-x-4 overflow-x-auto pb-4 no-scrollbar">
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $category): ?>
                    <a href="product.php?cat_id=<?= $category['id'] ?>" class="flex-shrink-0 text-center">
                        <div class="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-md p-2">
                            <img src="uploads/<?= htmlspecialchars($category['image']) ?>" alt="<?= htmlspecialchars($category['name']) ?>" class="h-12 w-12 object-contain">
                        </div>
                        <p class="mt-2 text-sm font-medium text-slate-600 w-20 truncate"><?= htmlspecialchars($category['name']) ?></p>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-slate-500">No categories found.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Featured Products Section -->
    <section>
        <h2 class="text-xl font-bold mb-4 text-slate-800">Featured Products</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="block">
                            <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-40 object-cover">
                        </a>
                        <div class="p-3 flex-grow flex flex-col justify-between">
                            <div>
                                <h3 class="font-semibold text-sm text-slate-700 truncate"><?= htmlspecialchars($product['name']) ?></h3>
                                <!-- FIX: Changed format_rupee() to format_taka() -->
                                <p class="text-lg font-bold text-indigo-600 mt-1"><?= format_taka($product['price']) ?></p>
                            </div>
                            <a href="product_detail.php?id=<?= $product['id'] ?>" class="mt-3 w-full bg-indigo-50 text-indigo-600 text-center py-2 rounded-lg text-sm font-semibold hover:bg-indigo-100 transition-colors">
                                View Details
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="col-span-full text-slate-500">No products found.</p>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php
if ($conn) { $conn->close(); }
include 'common/bottom.php';
?>