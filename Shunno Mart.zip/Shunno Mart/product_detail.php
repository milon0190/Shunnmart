<?php
// product_detail.php

// Always require the config file at the top to load functions and DB connection.
require_once 'common/config.php';

// --- Handle 'Add to Cart' AJAX requests ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 0);

    if ($product_id > 0 && $quantity > 0) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Update quantity if product is already in cart, otherwise add it.
        $_SESSION['cart'][$product_id] = isset($_SESSION['cart'][$product_id]) ? $_SESSION['cart'][$product_id] + $quantity : $quantity;
        
        $cart_count = count($_SESSION['cart']);
        json_response(['status' => 'success', 'message' => 'Product added to cart!', 'cart_count' => $cart_count]);
    } else {
        json_response(['status' => 'error', 'message' => 'Invalid product or quantity.'], 400);
    }
    exit;
}

// --- Fetch Product Details for Display ---
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($product_id <= 0) {
    header('Location: index.php');
    exit;
}

$product = null;
$related_products = [];

if ($conn && !$conn->connect_error) {
    // Fetch main product details
    $stmt = $conn->prepare("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.cat_id = c.id WHERE p.id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $stmt->close();

    if ($product) {
        // Fetch related products from the same category
        $stmt_related = $conn->prepare("SELECT id, name, price, image FROM products WHERE cat_id = ? AND id != ? ORDER BY RAND() LIMIT 4");
        $stmt_related->bind_param("ii", $product['cat_id'], $product_id);
        $stmt_related->execute();
        $result_related = $stmt_related->get_result();
        while ($row = $result_related->fetch_assoc()) {
            $related_products[] = $row;
        }
        $stmt_related->close();
    }
}

// If product not found, redirect to home
if (!$product) {
    header('Location: index.php');
    exit;
}

// Include HTML header and sidebar
include 'common/header.php';
include 'common/sidebar.php';
?>

<main class="p-4">
    <!-- Product Image Slider -->
    <div class="bg-white rounded-lg shadow-md mb-6 p-4">
        <img id="main-product-image" src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-64 object-contain rounded-md">
    </div>

    <!-- Product Info -->
    <div class="bg-white rounded-lg shadow-md p-4 mb-6">
        <h1 class="text-2xl font-bold text-slate-800"><?= htmlspecialchars($product['name']) ?></h1>
        <p class="text-sm text-slate-500 mt-1">in <a href="product.php?cat_id=<?= $product['cat_id'] ?>" class="text-indigo-600"><?= htmlspecialchars($product['category_name']) ?></a></p>
        
        <div class="flex items-center justify-between mt-4">
            <!-- FIX: Changed format_rupee() to format_taka() -->
            <p class="text-3xl font-extrabold text-indigo-600"><?= format_taka($product['price']) ?></p>
            <span class="px-3 py-1 text-sm font-semibold rounded-full <?= $product['stock'] > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                <?= $product['stock'] > 0 ? 'In Stock' : 'Out of Stock' ?>
            </span>
        </div>

        <div class="mt-6">
            <h2 class="text-lg font-semibold text-slate-700 mb-2">Description</h2>
            <p class="text-slate-600 leading-relaxed"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
        </div>
    </div>
    
    <!-- Add to Cart Form -->
    <?php if ($product['stock'] > 0): ?>
    <form id="add-to-cart-form" class="bg-white rounded-lg shadow-lg p-4 sticky bottom-20 z-30">
        <input type="hidden" name="action" value="add_to_cart">
        <input type="hidden" name="product_id" value="<?= $product_id ?>">
        <div class="flex items-center justify-between">
            <div class="flex items-center border border-slate-300 rounded-lg">
                <button type="button" id="qty-minus" class="px-3 py-2 text-lg text-slate-600">-</button>
                <input type="number" name="quantity" id="quantity" value="1" min="1" max="<?= $product['stock'] ?>" class="w-12 text-center border-none focus:ring-0 font-semibold bg-transparent">
                <button type="button" id="qty-plus" class="px-3 py-2 text-lg text-slate-600">+</button>
            </div>
            <button type="submit" class="flex-grow ml-4 bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
                <i class="fas fa-cart-plus mr-2"></i>Add to Cart
            </button>
        </div>
    </form>
    <?php endif; ?>

    <!-- Related Products -->
    <?php if (!empty($related_products)): ?>
    <section class="mt-8">
        <h2 class="text-xl font-bold mb-4 text-slate-800">Related Products</h2>
        <div class="grid grid-cols-2 gap-4">
            <?php foreach ($related_products as $related): ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <a href="product_detail.php?id=<?= $related['id'] ?>" class="block">
                    <img src="uploads/<?= htmlspecialchars($related['image']) ?>" alt="<?= htmlspecialchars($related['name']) ?>" class="w-full h-32 object-cover">
                </a>
                <div class="p-3">
                    <h3 class="font-semibold text-sm text-slate-700 truncate"><?= htmlspecialchars($related['name']) ?></h3>
                    <!-- FIX: Changed format_rupee() to format_taka() -->
                    <p class="text-md font-bold text-indigo-600 mt-1"><?= format_taka($related['price']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Quantity selector logic
    const qtyMinus = document.getElementById('qty-minus');
    const qtyPlus = document.getElementById('qty-plus');
    const quantityInput = document.getElementById('quantity');
    
    if(qtyMinus && qtyPlus && quantityInput) {
        const maxStock = parseInt(quantityInput.max);
        
        qtyMinus.addEventListener('click', () => {
            let currentVal = parseInt(quantityInput.value);
            if (currentVal > 1) quantityInput.value = currentVal - 1;
        });

        qtyPlus.addEventListener('click', () => {
            let currentVal = parseInt(quantityInput.value);
            if (currentVal < maxStock) quantityInput.value = currentVal + 1;
        });
    }

    // Add to cart form submission
    const addToCartForm = document.getElementById('add-to-cart-form');
    if(addToCartForm) {
        addToCartForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(addToCartForm);
            const response = await ajaxRequest('product_detail.php', { method: 'POST', body: formData });

            if (response && response.status === 'success') {
                showToast(response.message, 'success');
                // Update cart count badge in header
                const cartCountBadge = document.getElementById('cart-count-badge');
                if (cartCountBadge) {
                    cartCountBadge.textContent = response.cart_count;
                    cartCountBadge.classList.remove('hidden');
                } else {
                    location.reload(); 
                }
            } else if (response) {
                showToast(response.message, 'error');
            }
        });
    }
});
</script>

<?php
if ($conn) { $conn->close(); }
include 'common/bottom.php';
?>