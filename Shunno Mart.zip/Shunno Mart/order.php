<?php
require_once 'common/config.php';
require_login();

include 'common/header.php';
include 'common/sidebar.php';

$user_id = $_SESSION['user_id'];

// Fetch orders
$orders = [];
$stmt = $conn->prepare("
    SELECT o.id, o.total_amount, o.status, o.created_at, oi.quantity, p.name as product_name, p.image as product_image
    FROM orders o
    JOIN (
        SELECT order_id, MIN(id) as first_item_id
        FROM order_items
        GROUP BY order_id
    ) AS first_items ON o.id = first_items.order_id
    JOIN order_items oi ON oi.id = first_items.first_item_id
    JOIN products p ON oi.product_id = p.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}
$stmt->close();
$conn->close();

$active_orders = array_filter($orders, function($order) {
    return in_array($order['status'], ['Placed', 'Dispatched']);
});
$history_orders = array_filter($orders, function($order) {
    return in_array($order['status'], ['Delivered', 'Cancelled']);
});

function get_status_styles($status) {
    switch ($status) {
        case 'Placed': return 'bg-blue-100 text-blue-800';
        case 'Dispatched': return 'bg-yellow-100 text-yellow-800';
        case 'Delivered': return 'bg-green-100 text-green-800';
        case 'Cancelled': return 'bg-red-100 text-red-800';
        default: return 'bg-slate-100 text-slate-800';
    }
}
?>

<main class="p-4">
    <h1 class="text-2xl font-bold text-slate-800 mb-4">My Orders</h1>

    <!-- Tabs -->
    <div class="mb-4 border-b border-gray-200">
        <ul class="flex -mb-px" id="order-tabs">
            <li class="mr-2">
                <a href="#" class="tab-btn inline-block p-4 border-b-2 border-indigo-600 rounded-t-lg text-indigo-600 font-semibold" data-tab="active">Active Orders</a>
            </li>
            <li class="mr-2">
                <a href="#" class="tab-btn inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300 text-gray-500" data-tab="history">Order History</a>
            </li>
        </ul>
    </div>

    <!-- Tab Content -->
    <div id="tab-content">
        <!-- Active Orders Tab -->
        <div id="active-tab-content" class="tab-pane space-y-4">
            <?php if (!empty($active_orders)): ?>
                <?php foreach ($active_orders as $order): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <div class="p-4">
                            <div class="flex items-start space-x-4">
                                <img src="uploads/<?= htmlspecialchars($order['product_image']) ?>" class="w-20 h-20 object-cover rounded-md">
                                <div class="flex-grow">
                                    <h3 class="font-semibold text-slate-800 truncate"><?= htmlspecialchars($order['product_name']) ?></h3>
                                    <p class="text-sm text-slate-500">Order #<?= $order['id'] ?></p>
                                    <p class="text-sm text-slate-500">Placed on: <?= date('M d, Y', strtotime($order['created_at'])) ?></p>
                                    <span class="mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= get_status_styles($order['status']) ?>">
                                        <?= $order['status'] ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Progress Tracker -->
                        <div class="px-4 pb-4">
                            <?php 
                                $stages = ['Placed', 'Dispatched', 'Delivered'];
                                $current_stage_index = array_search($order['status'], $stages);
                                if ($current_stage_index === false) $current_stage_index = -1; // Handle 'Cancelled'
                            ?>
                             <div class="flex items-center">
                                <?php foreach ($stages as $index => $stage): 
                                    $is_completed = $index <= $current_stage_index;
                                    $is_active = $index === $current_stage_index;
                                    $icon_class = $is_completed ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-500';
                                    $text_class = $is_active ? 'text-indigo-600 font-semibold' : 'text-gray-500';
                                    $line_class = $index < $current_stage_index ? 'bg-indigo-600' : 'bg-gray-200';
                                    
                                    $icon = '';
                                    if ($stage == 'Placed') $icon = 'fa-box';
                                    if ($stage == 'Dispatched') $icon = 'fa-truck-fast';
                                    if ($stage == 'Delivered') $icon = 'fa-check-circle';
                                ?>
                                <div class="flex flex-col items-center">
                                    <div class="flex items-center justify-center w-8 h-8 rounded-full <?= $icon_class ?>">
                                        <i class="fas <?= $icon ?>"></i>
                                    </div>
                                    <p class="text-xs mt-1 <?= $text_class ?>"><?= $stage ?></p>
                                </div>
                                <?php if ($index < count($stages) - 1): ?>
                                    <div class="flex-auto border-t-2 h-0.5 <?= $line_class ?>"></div>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center text-slate-500 py-10">You have no active orders.</p>
            <?php endif; ?>
        </div>

        <!-- Order History Tab -->
        <div id="history-tab-content" class="tab-pane space-y-4 hidden">
            <?php if (!empty($history_orders)): ?>
                 <?php foreach ($history_orders as $order): ?>
                    <div class="bg-white rounded-lg shadow-md p-4">
                        <div class="flex items-start space-x-4">
                            <img src="uploads/<?= htmlspecialchars($order['product_image']) ?>" class="w-16 h-16 object-cover rounded-md">
                            <div class="flex-grow">
                                <h3 class="font-semibold text-slate-700 truncate"><?= htmlspecialchars($order['product_name']) ?></h3>
                                <p class="text-sm text-slate-500">Order #<?= $order['id'] ?></p>
                                <p class="text-sm text-slate-500">Date: <?= date('M d, Y', strtotime($order['created_at'])) ?></p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-slate-800"><?= format_rupee($order['total_amount']) ?></p>
                                 <span class="mt-1 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= get_status_styles($order['status']) ?>">
                                    <?= $order['status'] ?>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                 <p class="text-center text-slate-500 py-10">No past orders found.</p>
            <?php endif; ?>
        </div>
    </div>
</main>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.tab-btn');
    const panes = document.querySelectorAll('.tab-pane');

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();

            // Deactivate all tabs
            tabs.forEach(t => {
                t.classList.remove('border-indigo-600', 'text-indigo-600', 'font-semibold');
                t.classList.add('border-transparent', 'text-gray-500');
            });

            // Activate clicked tab
            tab.classList.add('border-indigo-600', 'text-indigo-600', 'font-semibold');
            tab.classList.remove('border-transparent', 'text-gray-500');

            // Hide all panes
            panes.forEach(pane => {
                pane.classList.add('hidden');
            });

            // Show corresponding pane
            const tabId = tab.dataset.tab;
            document.getElementById(`${tabId}-tab-content`).classList.remove('hidden');
        });
    });
});
</script>
<?php include 'common/bottom.php'; ?>