<?php
// checkout.php

require_once 'common/config.php';
require_login();

if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// --- Handle Order Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'place_order') {
    $user_id = $_SESSION['user_id'];
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST['phone'] ?? '');
    $address_line = trim($_POST['address_line'] ?? '');
    $division = trim($_POST['division'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $upazila = trim($_POST['upazila'] ?? '');
    $payment_method = trim($_POST['payment_method'] ?? '');
    $sender_number = trim($_POST['sender_number'] ?? null);
    $transaction_id = trim($_POST['transaction_id'] ?? null);
    
    if (empty($first_name) || empty($phone) || empty($address_line) || empty($division) || empty($city) || empty($upazila) || empty($payment_method)) {
        json_response(['status' => 'error', 'message' => 'Please fill all required address and payment fields.'], 400);
    }
    if (in_array($payment_method, ['Bkash', 'Nagad']) && (empty($sender_number) || empty($transaction_id))) {
        json_response(['status' => 'error', 'message' => 'Sender Number and Transaction ID are required for this payment method.'], 400);
    }
    
    $total_amount = 0; $cart_items_data = [];
    if (!empty($_SESSION['cart'])) {
        $product_ids = array_keys($_SESSION['cart']);
        $id_placeholders = implode(',', array_fill(0, count($product_ids), '?'));
        $types = str_repeat('i', count($product_ids));
        $stmt_prod = $conn->prepare("SELECT id, name, price, stock FROM products WHERE id IN ($id_placeholders)");
        $stmt_prod->bind_param($types, ...$product_ids);
        $stmt_prod->execute(); $result = $stmt_prod->get_result();
        while ($product = $result->fetch_assoc()) {
            $quantity = $_SESSION['cart'][$product['id']];
            if ($quantity > $product['stock']) { json_response(['status' => 'error', 'message' => "Stock out for {$product['name']}."], 400); }
            $total_amount += $product['price'] * $quantity;
            $cart_items_data[] = ['product_id' => $product['id'], 'quantity' => $quantity, 'price' => $product['price']];
        } $stmt_prod->close();
    } else { json_response(['status' => 'error', 'message' => 'Your cart is empty.'], 400); }

    $conn->begin_transaction();
    try {
        $stmt_order = $conn->prepare("INSERT INTO orders (user_id, first_name, last_name, email, phone, address_line, division, city, upazila, total_amount, payment_method, sender_number, transaction_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt_order->bind_param("isssssssssdss", $user_id, $first_name, $last_name, $email, $phone, $address_line, $division, $city, $upazila, $total_amount, $payment_method, $sender_number, $transaction_id);
        
        if (!$stmt_order->execute()) { throw new Exception("Order insertion failed: " . $stmt_order->error); }
        
        $order_id = $stmt_order->insert_id;
        $stmt_order->close();

        $stmt_items = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        foreach ($cart_items_data as $item) { $stmt_items->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']); $stmt_items->execute(); }
        $stmt_items->close();
        
        $conn->commit();
        unset($_SESSION['cart']);
        json_response(['status' => 'success', 'message' => 'Order placed successfully!', 'redirect' => 'order.php?success=' . $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        json_response(['status' => 'error', 'message' => 'An error occurred. Please try again. Details: ' . $e->getMessage()], 500);
    }
    // THE FIX IS HERE: The exit call was moved inside the if block,
    // so it only runs for AJAX requests.
    exit;
}

// --- This part now runs correctly for page loads ---
$user_data = [];
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT name, email, phone, address_line FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if($result) $user_data = $result->fetch_assoc();
$stmt->close();

$name_parts = explode(' ', $user_data['name'] ?? '', 2);
$first_name = $name_parts[0] ?? '';
$last_name = $name_parts[1] ?? '';

include 'common/header.php';
include 'common/sidebar.php';
?>
<main class="p-4 bg-slate-50 pb-24">
    <h1 class="text-2xl font-bold text-slate-800 mb-6">Checkout</h1>

    <form id="checkout-main-form">
        <!-- Step 1: Address Form -->
        <div id="address-step" class="bg-white rounded-lg shadow-md p-5 space-y-4">
            <h2 class="text-lg font-semibold border-b pb-3 mb-4">1. Shipping Address</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-5">
                <div><label for="first_name" class="label-style">First Name</label><input type="text" id="first_name" name="first_name" value="<?= htmlspecialchars($first_name) ?>" required class="input-style"></div>
                <div><label for="last_name" class="label-style">Last Name</label><input type="text" id="last_name" name="last_name" value="<?= htmlspecialchars($last_name) ?>" required class="input-style"></div>
                <div class="sm:col-span-2"><label for="phone" class="label-style">Phone Number</label><input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($user_data['phone'] ?? '') ?>" required class="input-style"></div>
                <div class="sm:col-span-2"><label for="email" class="label-style">Email Address</label><input type="email" id="email" name="email" value="<?= htmlspecialchars($user_data['email'] ?? '') ?>" required class="input-style"></div>
                <div><label for="division" class="label-style">Division</label><select id="division" name="division" required class="input-style"></select></div>
                <div><label for="city" class="label-style">District / City</label><select id="city" name="city" required class="input-style" disabled></select></div>
                <div><label for="upazila" class="label-style">Upazila / Thana</label><select id="upazila" name="upazila" required class="input-style" disabled></select></div>
                <div class="sm:col-span-2"><label for="address_line" class="label-style">Area, Street, House No.</label><textarea id="address_line" name="address_line" rows="3" required class="input-style" placeholder="e.g., House #123, Road #4, Mirpur-10"><?= htmlspecialchars($user_data['address_line'] ?? '') ?></textarea></div>
            </div>
            <button type="button" id="next-to-payment-btn" class="w-full mt-4 bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-700">Next: Choose Payment</button>
        </div>

        <!-- Step 2: Payment Method (Hidden by default) -->
        <div id="payment-step" class="hidden mt-6 bg-white rounded-lg shadow-md p-5 space-y-4">
            <div class="flex justify-between items-center border-b pb-3 mb-4">
                <h2 class="text-lg font-semibold">2. Payment Method</h2>
                <button type="button" id="back-to-address-btn" class="text-sm text-indigo-600 font-semibold hover:underline">Edit Address</button>
            </div>
            <div class="space-y-3">
                <label class="payment-option-label"><input type="radio" name="payment_method_radio" value="Card"><span class="ml-3 flex items-center"><i class="fas fa-credit-card mr-3 text-lg text-blue-600"></i> Card Payment</span></label>
                <label class="payment-option-label"><input type="radio" name="payment_method_radio" value="Bank"><span class="ml-3 flex items-center"><i class="fas fa-university mr-3 text-lg text-purple-600"></i> Bank Transfer</span></label>
                <label class="payment-option-label"><input type="radio" name="payment_method_radio" value="Mobile"><span class="ml-3 flex items-center"><i class="fas fa-mobile-alt mr-3 text-lg text-pink-600"></i> Mobile Banking</span></label>
                <label class="payment-option-label"><input type="radio" name="payment_method_radio" value="COD"><span class="ml-3 flex items-center"><i class="fas fa-hand-holding-usd mr-3 text-lg text-green-600"></i> Cash on Delivery</span></label>
            </div>
            <div id="payment-details-container" class="mt-4">
                <div id="cod-details" class="payment-details hidden"><h4 class="font-semibold mb-2">Cash on Delivery - Terms & Conditions</h4><div class="text-sm text-slate-600 p-3 bg-slate-50 rounded-md space-y-2"><div>📦 <strong>ডেলিভারি সময়:</strong> ঢাকার ভিতরে (১-৩ দিন), ঢাকার বাইরে (৩-৭ দিন)।</div><div>💵 <strong>পেমেন্ট:</strong> পণ্যের ডেলিভারির সময় সম্পূর্ণ টাকা ক্যাশে প্রদান করতে হবে।</div></div></div>
                <div id="mobile-details" class="payment-details hidden">
                    <div class="flex space-x-1 border-b mb-3"><button type="button" class="mobile-brand-btn active-brand" data-brand="Bkash">bKash</button><button type="button" class="mobile-brand-btn" data-brand="Nagad">Nagad</button><button type="button" class="mobile-brand-btn" data-brand="Rocket">Rocket</button><button type="button" class="mobile-brand-btn" data-brand="Upay">Upay</button></div>
                    <div id="bkash-tutorial" class="mobile-tutorial"><p class="mb-2">Admin bKash Number: <strong id="bkash-num">01776934921</strong> <button type="button" onclick="copyToClipboard('#bkash-num')" class="copy-btn"><i class="fas fa-copy"></i></button></p><div class="tutorial-box"><strong>🟢 Bkash App Send Money:</strong><ol class="list-decimal list-inside text-xs space-y-1"><li>Login to bKash App > Send Money</li><li>Enter Number: 01776934921</li><li>Enter Amount & Reference: Payment</li><li>Confirm with PIN</li></ol></div><div class="mt-4 space-y-3"><input type="tel" name="sender_number_bkash" placeholder="Your bKash Number" class="input-style w-full"><input type="text" name="transaction_id_bkash" placeholder="Transaction ID (TrxID)" class="input-style w-full"></div></div>
                    <div id="nagad-tutorial" class="mobile-tutorial hidden"><p class="mb-2">Admin Nagad Number: <strong id="nagad-num">01776934921</strong> <button type="button" onclick="copyToClipboard('#nagad-num')" class="copy-btn"><i class="fas fa-copy"></i></button></p><div class="tutorial-box"><strong>🟢 Nagad App Send Money:</strong><ol class="list-decimal list-inside text-xs space-y-1"><li>Login to Nagad App > Send Money</li><li>Enter Number: 01776934921</li><li>Enter Amount & Reference: Payment</li><li>Confirm with PIN</li></ol></div><div class="mt-4 space-y-3"><input type="tel" name="sender_number_nagad" placeholder="Your Nagad Number" class="input-style w-full"><input type="text" name="transaction_id_nagad" placeholder="Transaction ID (TrxID)" class="input-style w-full"></div></div>
                </div>
            </div>
            <button type="submit" id="place-order-btn" class="w-full bg-green-600 text-white font-bold py-3 rounded-lg hover:bg-green-700 disabled:bg-slate-400" disabled>Place Order</button>
        </div>
    </form>
</main>
<div id="error-modal" class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[100] hidden"><div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm text-center"><h3 id="error-modal-title" class="text-lg font-bold text-red-600 mb-3"></h3><div id="error-modal-body" class="text-slate-600 space-y-2"></div><button id="error-modal-close" class="mt-4 bg-slate-200 text-slate-800 py-2 px-6 rounded-lg">Close</button></div></div>
<style>.label-style{display:block;font-size:.875rem;font-weight:500;color:#475569;margin-bottom:.5rem}.input-style{display:block;width:100%;padding:.65rem .75rem;border:1px solid #cbd5e1;border-radius:.5rem;background-color:#f8fafc;transition:all .2s ease-in-out}.input-style:focus{outline:none;border-color:#4f46e5;background-color:#fff;box-shadow:0 0 0 2px rgba(99,102,241,.2)}.payment-option-label{display:flex;align-items:center;padding:.75rem;border:1px solid #e2e8f0;border-radius:.5rem;cursor:pointer;transition:all .2s}.payment-option-label:has(:checked){background-color:#eef2ff;border-color:#6366f1}.payment-details{border:1px solid #e2e8f0;padding:1rem;border-radius:.5rem}.mobile-brand-btn{padding:6px 12px;border-bottom:2px solid transparent;font-semibold;color:#475569;}.mobile-brand-btn.active-brand{border-color:#4f46e5;color:#4f46e5;}.tutorial-box{background-color:#f8fafc;padding:.75rem;border-radius:.375rem;font-size:.875rem;color:#334155;}.copy-btn{background:#eef2ff;color:#4f46e5;border:none;border-radius:4px;padding:2px 6px;margin-left:8px;cursor:pointer;}</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // --- ELEMENT SELECTORS ---
    const mainForm = document.getElementById('checkout-main-form');
    const addressStep = document.getElementById('address-step');
    const paymentStep = document.getElementById('payment-step');
    const nextBtn = document.getElementById('next-to-payment-btn');
    const backBtn = document.getElementById('back-to-address-btn');
    const placeOrderBtn = document.getElementById('place-order-btn');

    // --- STEP NAVIGATION LOGIC ---
    nextBtn.addEventListener('click', () => {
        let isValid = true;
        addressStep.querySelectorAll('[required]').forEach(input => { if (!input.value) isValid = false; });
        if (isValid) {
            addressStep.classList.add('hidden');
            paymentStep.classList.remove('hidden');
            window.scrollTo(0, 0);
        } else {
            showToast('Please fill all required address fields.', 'error');
        }
    });

    backBtn.addEventListener('click', () => {
        paymentStep.classList.add('hidden');
        addressStep.classList.remove('hidden');
        window.scrollTo(0, 0);
    });
    
    // --- PAYMENT METHOD LOGIC ---
    document.querySelectorAll('input[name="payment_method_radio"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
            document.querySelectorAll('.payment-details').forEach(d => d.classList.add('hidden'));
            placeOrderBtn.disabled = true;
            const selectedValue = e.target.value;

            if (selectedValue === 'COD') { document.getElementById('cod-details').classList.remove('hidden'); placeOrderBtn.disabled = false; } 
            else if (selectedValue === 'Mobile') { document.getElementById('mobile-details').classList.remove('hidden'); document.querySelector('.mobile-brand-btn[data-brand="Bkash"]').click(); } 
            else if (selectedValue === 'Card') { showErrorPopup("কার্ড পেমেন্ট বন্ধ", `<p>বর্তমানে আমাদের ওয়েবসাইটে কার্ড পেমেন্ট সাময়িকভাবে বন্ধ রয়েছে।</p><p class="mt-2">আমরা শুধুমাত্র নিচের মোবাইল পেমেন্ট মাধ্যমগুলো গ্রহণ করছি:</p><p class="font-semibold text-green-600">✅ Bkash</p><p class="font-semibold text-green-600">✅ Nagad</p>`); } 
            else if (selectedValue === 'Bank') { showErrorPopup("ব্যাংক ট্রান্সফার বন্ধ", `<p>বর্তমানে আমাদের ওয়েবসাইটে ব্যাংক ট্রান্সফার সাময়িকভাবে বন্ধ রয়েছে।</p><p class="mt-2">আমরা শুধুমাত্র নিচের মোবাইল পেমেন্ট মাধ্যমগুলো গ্রহণ করছি:</p><p class="font-semibold text-green-600">✅ Bkash</p><p class="font-semibold text-green-600">✅ Nagad</p>`); }
        });
    });

    document.querySelectorAll('.mobile-brand-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.mobile-brand-btn').forEach(b => b.classList.remove('active-brand'));
            btn.classList.add('active-brand');
            document.querySelectorAll('.mobile-tutorial').forEach(t => t.classList.add('hidden'));
            placeOrderBtn.disabled = true;

            const brand = btn.dataset.brand;
            if (brand === 'Bkash' || brand === 'Nagad') {
                document.getElementById(`${brand.toLowerCase()}-tutorial`).classList.remove('hidden');
                placeOrderBtn.disabled = false;
            } else { 
                showErrorPopup(`${brand} পেমেন্ট বন্ধ`, `<p>বর্তমানে আমাদের ওয়েবসাইটে ${brand} পেমেন্ট সাময়িকভাবে বন্ধ রয়েছে।</p><p class="mt-2">আমরা শুধুমাত্র নিচের মোবাইল পেমেন্ট মাধ্যমগুলো গ্রহণ করছি:</p><p class="font-semibold text-green-600">✅ Bkash</p><p class="font-semibold text-green-600">✅ Nagad</p>`);
            }
        });
    });

    // --- FINAL FORM SUBMISSION ---
    mainForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const finalFormData = new FormData(mainForm);
        const paymentRadio = document.querySelector('input[name="payment_method_radio"]:checked');
        let paymentMethodValue = paymentRadio ? paymentRadio.value : '';

        if(paymentMethodValue === 'Mobile') {
            paymentMethodValue = document.querySelector('.mobile-brand-btn.active-brand').dataset.brand;
            const senderInput = document.querySelector(`#${paymentMethodValue.toLowerCase()}-tutorial input[name^="sender_number"]`);
            const trxInput = document.querySelector(`#${paymentMethodValue.toLowerCase()}-tutorial input[name^="transaction_id"]`);
            finalFormData.append('sender_number', senderInput ? senderInput.value : '');
            finalFormData.append('transaction_id', trxInput ? trxInput.value : '');
        }
        finalFormData.set('payment_method', paymentMethodValue);
        finalFormData.append('action', 'place_order');
        
        const response = await ajaxRequest('checkout.php', { method: 'POST', body: finalFormData });
        if (response && response.status === 'success') {
            showToast(response.message, 'success');
            window.location.href = response.redirect;
        } else if (response) {
            showToast(response.message, 'error');
        }
    });

    // --- Helper & Location Functions ---
    function showErrorPopup(title, bodyHtml) { document.getElementById('error-modal-title').textContent = title; document.getElementById('error-modal-body').innerHTML = bodyHtml; document.getElementById('error-modal').classList.remove('hidden'); document.getElementById('error-modal-close').onclick = () => document.getElementById('error-modal').classList.add('hidden'); }
    window.copyToClipboard = (elementSelector) => navigator.clipboard.writeText(document.querySelector(elementSelector).innerText).then(() => showToast('Number copied!', 'success'));
    let locationData = {};
    const divisionSelect = document.getElementById('division');
    const citySelect = document.getElementById('city');
    const upazilaSelect = document.getElementById('upazila');
    async function loadLocations() { try { const response = await fetch('assets/js/bd-locations.json'); if (!response.ok) throw new Error('Failed to load location data'); locationData = await response.json(); populateDivisions(); } catch (error) { console.error(error); } }
    function populateDivisions() { divisionSelect.innerHTML = '<option value="">-- Select Division --</option>'; locationData.divisions.forEach(div => divisionSelect.add(new Option(`${div.name} (${div.bn_name})`, div.name))); }
    divisionSelect.onchange = () => { citySelect.innerHTML = '<option value="">-- Select District --</option>'; upazilaSelect.innerHTML = '<option value="">-- Select Upazila --</option>'; citySelect.disabled = true; upazilaSelect.disabled = true; const selectedDivision = locationData.divisions.find(d => d.name === divisionSelect.value); if (selectedDivision) { const districts = locationData.districts.filter(d => d.division_id === selectedDivision.id); districts.forEach(dist => citySelect.add(new Option(`${dist.name} (${dist.bn_name})`, dist.name))); citySelect.disabled = false; } };
    citySelect.onchange = () => { upazilaSelect.innerHTML = '<option value="">-- Select Upazila --</option>'; upazilaSelect.disabled = true; const selectedDistrict = locationData.districts.find(d => d.name === citySelect.value); if (selectedDistrict) { const upazilas = locationData.upazilas.filter(u => u.district_id === selectedDistrict.id); upazilas.forEach(upazila => upazilaSelect.add(new Option(`${upazila.name} (${upazila.bn_name})`, upazila.name))); upazilaSelect.disabled = false; } };
    loadLocations();
});
</script>

<?php
if ($conn) { $conn->close(); }
include 'common/bottom.php';
?>