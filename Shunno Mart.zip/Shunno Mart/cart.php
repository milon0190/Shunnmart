<?php
// cart.php

// Always require the config file at the top to load functions and DB connection.
require_once 'common/config.php';

// --- Handle AJAX cart updates ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $product_id = (int)($_POST['product_id'] ?? 0);

    if ($product_id <= 0) { json_response(['status' => 'error', 'message' => 'Invalid product ID.'], 400); }
    if (!isset($_SESSION['cart'][$product_id])) { json_response(['status' => 'error', 'message' => 'Product not in cart.'], 404); }

    if ($action === 'update_quantity') {
        $quantity = (int)($_POST['quantity'] ?? 1);
        if ($quantity > 0) {
            $_SESSION['cart'][$product_id] = $quantity;
            json_response(['status' => 'success', 'message' => 'Cart updated.']);
        } else {
            unset($_SESSION['cart'][$product_id]);
            json_response(['status' => 'success', 'message' => 'Item removed.', 'removed' => true]);
        }
    } elseif ($action === 'remove_item') {
        unset($_SESSION['cart'][$product_id]);
        json_response(['status' => 'success', 'message' => 'Item removed from cart.']);
    }
    exit;
}

// --- Fetch Cart Items for Display ---
$cart_items = [];
$total_price = 0;

if (!empty($_SESSION['cart']) && $conn && !$conn->connect_error) {
    $product_ids = array_keys($_SESSION['cart']);
    $id_placeholders = implode(',', array_fill(0, count($product_ids), '?'));
    $types = str_repeat('i', count($product_ids));
    
    $stmt = $conn->prepare("SELECT id, name, price, image, stock FROM products WHERE id IN ($id_placeholders)");
    $stmt->bind_param($types, ...$product_ids);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($product = $result->fetch_assoc()) {
        $quantity = $_SESSION['cart'][$product['id']];
        // Ensure cart quantity doesn't exceed available stock
        if ($quantity > $product['stock']) {
            $quantity = $product['stock'];
            $_SESSION['cart'][$product['id']] = $quantity;
        }
        $product['quantity'] = $quantity;
        $product['subtotal'] = $product['price'] * $quantity;
        $cart_items[] = $product;
        $total_price += $product['subtotal'];
    }
    $stmt->close();
}

// Include HTML header and sidebar
include 'common/header.php';
include 'common/sidebar.php';
?>
<main class="p-4">
    <h1 class="text-2xl font-bold text-slate-800 mb-6">My Cart</h1>

    <div id="cart-container">
        <?php if (!empty($cart_items)): ?>
            <div class="space-y-4">
                <?php foreach ($cart_items as $item): ?>
                    <div id="cart-item-<?= $item['id'] ?>" class="bg-white rounded-lg shadow-md p-3 flex items-start space-x-4">
                        <img src="uploads/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="w-20 h-20 object-cover rounded-md flex-shrink-0">
                        <div class="flex-grow">
                            <h2 class="font-semibold text-slate-700"><?= htmlspecialchars($item['name']) ?></h2>
                            <!-- FIX: Changed format_rupee() to format_taka() -->
                            <p class="text-sm text-slate-500">Price: <?= format_taka($item['price']) ?></p>
                            <div class="flex items-center mt-2">
                                <label class="text-sm mr-2 font-medium">Qty:</label>
                                <input type="number" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>" 
                                       data-product-id="<?= $item['id'] ?>" 
                                       class="cart-quantity-input w-16 p-1 border border-slate-300 rounded-md text-center">
                            </div>
                        </div>
                        <div class="text-right flex-shrink-0">
                            <!-- FIX: Changed format_rupee() to format_taka() -->
                            <p class="font-bold text-indigo-600" id="subtotal-<?= $item['id'] ?>"><?= format_taka($item['subtotal']) ?></p>
                            <button class="remove-item-btn text-red-500 hover:text-red-700 text-sm mt-2" data-product-id="<?= $item['id'] ?>">
                                <i class="fas fa-trash-alt mr-1"></i> Remove
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Cart Summary -->
            <div class="mt-6 bg-white rounded-lg shadow-lg p-4 sticky bottom-20 z-30">
                <div class="flex justify-between items-center mb-4">
                    <span class="text-lg font-semibold text-slate-700">Total</span>
                    <!-- FIX: Changed format_rupee() to format_taka() -->
                    <span id="total-price" class="text-2xl font-bold text-indigo-600"><?= format_taka($total_price) ?></span>
                </div>
                <a href="checkout.php" class="block w-full text-center bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-700 transition-colors">
                    Proceed to Checkout
                </a>
            </div>
        <?php else: ?>
            <div id="empty-cart-message" class="text-center py-20">
                <i class="fas fa-shopping-cart text-6xl text-slate-300"></i>
                <h2 class="mt-4 text-xl font-semibold text-slate-600">Your cart is empty</h2>
                <p class="text-slate-500 mt-2">Looks like you haven't added anything yet.</p>
                <a href="index.php" class="mt-6 inline-block bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors">
                    Start Shopping
                </a>
            </div>
        <?php endif; ?>
    </div>
</main>
<script>
document.addEventListener('DOMContentLoaded', () => {

    async function updateCart(productId, action, quantity = null) {
        const formData = new FormData();
        formData.append('product_id', productId);
        formData.append('action', action);
        if (quantity !== null) {
            formData.append('quantity', quantity);
        }
        
        const response = await ajaxRequest('cart.php', { method: 'POST', body: formData });
        
        if (response && response.status === 'success') {
            showToast(response.message);
            // Reloading the page is the simplest way to update everything.
            location.reload();
        } else if (response) {
            showToast(response.message, 'error');
        }
    }

    document.querySelectorAll('.cart-quantity-input').forEach(input => {
        input.addEventListener('change', (e) => {
            const productId = e.target.dataset.productId;
            const quantity = e.target.value;
            updateCart(productId, 'update_quantity', quantity);
        });
    });

    document.querySelectorAll('.remove-item-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = e.currentTarget.dataset.productId;
            if (confirm('Are you sure you want to remove this item?')) {
                updateCart(productId, 'remove_item');
            }
        });
    });
});
</script>
<?php
if ($conn) { $conn->close(); }
include 'common/bottom.php';
?>