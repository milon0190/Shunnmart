<?php
// profile.php

require_once 'common/config.php';
require_login();

// Handle Logout Action
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle Profile Update / Password Change via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $address_line = trim($_POST['address_line'] ?? '');
        
        if (empty($name) || empty($phone) || empty($email)) {
            json_response(['status' => 'error', 'message' => 'Name, Phone and Email are required.'], 400);
        }

        $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, email = ?, address_line = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $name, $phone, $email, $address_line, $user_id);
        
        if ($stmt->execute()) {
            $_SESSION['user_name'] = $name; // Update session name
            json_response(['status' => 'success', 'message' => 'Profile updated successfully.']);
        } else {
            json_response(['status' => 'error', 'message' => 'Update failed. Email might be in use.'], 500);
        }
        $stmt->close();

    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        
        if (empty($current_password) || empty($new_password)) { json_response(['status' => 'error', 'message' => 'All password fields are required.'], 400); }
        if (strlen($new_password) < 6) { json_response(['status' => 'error', 'message' => 'New password must be at least 6 characters.'], 400); }

        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($current_password, $user['password'])) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $update_stmt->bind_param("si", $hashed_password, $user_id);
            if ($update_stmt->execute()) { json_response(['status' => 'success', 'message' => 'Password changed successfully.']); } 
            else { json_response(['status' => 'error', 'message' => 'Failed to change password.'], 500); }
            $update_stmt->close();
        } else {
            json_response(['status' => 'error', 'message' => 'Incorrect current password.'], 401);
        }
        $stmt->close();
    }
    exit;
}

// Fetch user data for displaying on the page
$user = [];
if (isset($conn)) {
    $stmt = $conn->prepare("SELECT name, email, phone, address_line FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
}
// Do NOT close the connection here, let it be open for the sidebar

include 'common/header.php';
include 'common/sidebar.php';
?>
<main class="p-4 bg-slate-50 pb-24">
    <h1 class="text-2xl font-bold text-slate-800 mb-6">My Profile</h1>

    <!-- Edit Profile Form -->
    <div class="bg-white rounded-lg shadow-md p-5 mb-6">
        <h2 class="text-lg font-semibold border-b pb-3 mb-4">Edit Information</h2>
        <form id="profile-form" class="space-y-5">
            <input type="hidden" name="action" value="update_profile">
             <div>
                <label for="name" class="label-style">Full Name</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>" required class="input-style">
            </div>
             <div>
                <label for="email" class="label-style">Email</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required class="input-style">
            </div>
             <div>
                <label for="phone" class="label-style">Phone</label>
                <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required class="input-style">
            </div>
            <div>
                <label for="address" class="label-style">Address</label>
                <textarea id="address" name="address_line" rows="2" class="input-style" placeholder="e.g., House #123, Road #4, Mirpur-10"><?= htmlspecialchars($user['address_line'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors">Save Changes</button>
        </form>
    </div>

    <!-- Change Password Form -->
    <div class="bg-white rounded-lg shadow-md p-5 mb-6">
        <h2 class="text-lg font-semibold border-b pb-3 mb-4">Change Password</h2>
        <form id="password-form" class="space-y-5">
            <input type="hidden" name="action" value="change_password">
             <div>
                <label for="current_password" class="label-style">Current Password</label>
                <input type="password" id="current_password" name="current_password" required class="input-style">
            </div>
             <div>
                <label for="new_password" class="label-style">New Password</label>
                <input type="password" id="new_password" name="new_password" required class="input-style">
            </div>
            <button type="submit" class="w-full bg-slate-700 text-white font-bold py-3 px-4 rounded-lg hover:bg-slate-800 transition-colors">Update Password</button>
        </form>
    </div>

    <!-- Logout Button -->
    <a href="profile.php?action=logout" class="block w-full text-center bg-red-500 text-white font-bold py-3 rounded-lg hover:bg-red-600 transition-colors">
        Logout
    </a>
</main>
<style>.label-style {display:block;font-size:0.875rem;font-weight:500;color:#475569;margin-bottom:0.5rem;}.input-style {display:block;width:100%;padding:0.65rem .75rem;border:1px solid #cbd5e1;border-radius:0.5rem;background-color:#f8fafc;transition:all 0.2s ease-in-out;}.input-style:focus{outline:none;border-color:#4f46e5;background-color:#fff;box-shadow:0 0 0 2px rgba(99,102,241,0.2);}</style>
<script>
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('profile-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const response = await ajaxRequest('profile.php', { method: 'POST', body: formData });
        if (response && response.status === 'success') {
            showToast(response.message, 'success');
        } else if (response) {
            showToast(response.message, 'error');
        }
    });

    document.getElementById('password-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const response = await ajaxRequest('profile.php', { method: 'POST', body: formData });
        if (response && response.status === 'success') {
            showToast(response.message, 'success');
            e.target.reset();
        } else if (response) {
            showToast(response.message, 'error');
        }
    });
});
</script>
<?php
// Close the connection at the very end of the script
if ($conn) { $conn->close(); }
include 'common/bottom.php';
?>