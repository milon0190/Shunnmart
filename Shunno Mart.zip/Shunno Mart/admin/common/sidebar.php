<?php
$current_page = basename($_SERVER['PHP_SELF']);
$nav_items = [
    'index.php' => ['icon' => 'fa-tachometer-alt', 'label' => 'Dashboard'],
    'order.php' => ['icon' => 'fa-box-open', 'label' => 'Orders'],
    'product.php' => ['icon' => 'fa-shopping-bag', 'label' => 'Products'],
    'category.php' => ['icon' => 'fa-tags', 'label' => 'Categories'],
    'user.php' => ['icon' => 'fa-users', 'label' => 'Users'],
    'setting.php' => ['icon' => 'fa-cog', 'label' => 'Settings']
];
?>
<!-- Sidebar Overlay for mobile -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden lg:hidden"></div>

<!-- Sidebar -->
<aside id="sidebar" class="fixed lg:relative top-0 left-0 h-full w-64 bg-gray-800 text-gray-300 shadow-lg z-50 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out">
    <div class="p-4 flex items-center justify-between border-b border-gray-700">
        <a href="index.php" class="text-2xl font-bold text-white">Shunno Admin</a>
         <button id="close-sidebar" class="text-xl text-gray-400 lg:hidden">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <nav class="mt-4 flex flex-col justify-between h-[calc(100%-100px)]">
        <ul class="flex flex-col space-y-2 px-2">
            <?php foreach($nav_items as $file => $item): 
                $isActive = ($current_page == $file || ($current_page == 'order_detail.php' && $file == 'order.php'));
            ?>
            <li>
                <a href="<?= $file ?>" class="flex items-center py-2 px-3 rounded-md transition-colors <?= $isActive ? 'bg-gray-700 text-white' : 'hover:bg-gray-700 hover:text-white' ?>">
                    <i class="fas <?= $item['icon'] ?> w-6 text-center"></i>
                    <span class="ml-3"><?= $item['label'] ?></span>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
        <div class="px-2 pb-4">
             <a href="login.php?action=logout" class="flex items-center py-2 px-3 rounded-md transition-colors text-red-400 hover:bg-red-900 hover:text-white">
                <i class="fas fa-sign-out-alt w-6 text-center"></i>
                <span class="ml-3">Logout</span>
            </a>
        </div>
    </nav>
</aside>