<?php
require_once '../common/config.php';
require_admin_login();

$orders = [];
$result = $conn->query("
    SELECT o.id, u.name as user_name, o.total_amount, o.status, o.created_at 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}

include 'common/header.php';
?>
<div class="bg-white rounded-lg shadow-md overflow-x-auto">
    <table class="w-full text-sm text-left text-slate-500">
        <thead class="text-xs text-slate-700 uppercase bg-slate-50">
            <tr>
                <th class="px-6 py-3">Order ID</th>
                <th class="px-6 py-3">Customer</th>
                <th class="px-6 py-3">Date</th>
                <th class="px-6 py-3">Amount</th>
                <th class="px-6 py-3">Status</th>
                <th class="px-6 py-3 text-right">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($orders as $order): ?>
            <tr class="bg-white border-b hover:bg-slate-50">
                <td class="px-6 py-4 font-medium">#<?= $order['id'] ?></td>
                <td class="px-6 py-4"><?= htmlspecialchars($order['user_name']) ?></td>
                <td class="px-6 py-4"><?= date('d M, Y', strtotime($order['created_at'])) ?></td>
                <!-- FIX: Changed format_rupee to format_taka -->
                <td class="px-6 py-4"><?= format_taka($order['total_amount']) ?></td>
                <td class="px-6 py-4">
                     <span class="px-2 py-1 font-semibold leading-tight rounded-full text-xs
                        <?= $order['status'] == 'Delivered' ? 'bg-green-100 text-green-700' : '' ?>
                        <?= $order['status'] == 'Placed' ? 'bg-blue-100 text-blue-700' : '' ?>
                        <?= $order['status'] == 'Dispatched' ? 'bg-yellow-100 text-yellow-700' : '' ?>
                        <?= $order['status'] == 'Cancelled' ? 'bg-red-100 text-red-700' : '' ?>
                    ">
                        <?= $order['status'] ?>
                    </span>
                </td>
                <td class="px-6 py-4 text-right">
                    <a href="order_detail.php?id=<?= $order['id'] ?>" class="font-medium text-indigo-600 hover:underline">View Details</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'common/bottom.php';
?>