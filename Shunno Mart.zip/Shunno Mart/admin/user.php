<?php
require_once '../common/config.php';
require_admin_login();

$users = [];
$result = $conn->query("SELECT id, name, email, phone, created_at FROM users ORDER BY created_at DESC");
if ($result) {
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

include 'common/header.php';
?>
<div class="bg-white rounded-lg shadow-md overflow-x-auto">
    <table class="w-full text-sm text-left text-slate-500">
        <thead class="text-xs text-slate-700 uppercase bg-slate-50">
            <tr>
                <th class="px-6 py-3">User ID</th>
                <th class="px-6 py-3">Name</th>
                <th class="px-6 py-3">Email</th>
                <th class="px-6 py-3">Phone</th>
                <th class="px-6 py-3">Joined On</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($users as $user): ?>
            <tr class="bg-white border-b hover:bg-slate-50">
                <td class="px-6 py-4">#<?= $user['id'] ?></td>
                <td class="px-6 py-4 font-medium text-slate-900"><?= htmlspecialchars($user['name']) ?></td>
                <td class="px-6 py-4"><?= htmlspecialchars($user['email']) ?></td>
                <td class="px-6 py-4"><?= htmlspecialchars($user['phone']) ?></td>
                <td class="px-6 py-4"><?= date('d M, Y', strtotime($user['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'common/bottom.php';
?>