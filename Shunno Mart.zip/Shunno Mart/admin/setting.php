<?php
require_once '../common/config.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin_id = $_SESSION['admin_id'];
    $username = trim($_POST['username'] ?? '');
    $new_password = $_POST['new_password'] ?? '';

    if (empty($username)) {
        $message = ['type' => 'error', 'text' => 'Username cannot be empty.'];
    } else {
        if (!empty($new_password)) {
            if (strlen($new_password) < 6) {
                 $message = ['type' => 'error', 'text' => 'New password must be at least 6 characters.'];
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE admin SET username = ?, password = ? WHERE id = ?");
                $stmt->bind_param("ssi", $username, $hashed_password, $admin_id);
            }
        } else {
            $stmt = $conn->prepare("UPDATE admin SET username = ? WHERE id = ?");
            $stmt->bind_param("si", $username, $admin_id);
        }

        if (!isset($message) && isset($stmt) && $stmt->execute()) {
            $_SESSION['admin_user'] = $username;
            $message = ['type' => 'success', 'text' => 'Settings updated successfully.'];
        } elseif (!isset($message)) {
            $message = ['type' => 'error', 'text' => 'Failed to update settings. Username might be taken.'];
        }
    }
}

// Fetch current admin info
$admin_id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT username FROM admin WHERE id = $admin_id")->fetch_assoc();


include 'common/header.php';
?>
<div class="max-w-xl mx-auto">
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold mb-4">Admin Settings</h2>

        <?php if (isset($message)): ?>
        <div class="p-4 mb-4 text-sm rounded-lg <?= $message['type'] == 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
            <?= $message['text'] ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="setting.php" class="space-y-4">
            <div>
                <label for="username" class="block text-sm font-medium text-slate-600">Username</label>
                <input type="text" name="username" id="username" value="<?= htmlspecialchars($admin['username']) ?>" class="mt-1 block w-full input-style" required>
            </div>
            <div>
                <label for="new_password" class="block text-sm font-medium text-slate-600">New Password</label>
                <input type="password" name="new_password" id="new_password" class="mt-1 block w-full input-style" placeholder="Leave blank to keep current password">
                <p class="text-xs text-slate-500 mt-1">Must be at least 6 characters long.</p>
            </div>
            <button type="submit" class="w-full bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700">Save Settings</button>
        </form>
    </div>
</div>
<style>.input-style{padding:.5rem .75rem;border:1px solid #cbd5e1;border-radius:.375rem}.input-style:focus{outline:none;border-color:#6366f1;box-shadow:0 0 0 1px #6366f1}</style>
<?php
$conn->close();
include 'common/bottom.php';
?>