<?php
require_once '../common/config.php';
require_admin_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $valid_statuses = ['Placed', 'Dispatched', 'Delivered', 'Cancelled'];

    if ($order_id > 0 && in_array($status, $valid_statuses)) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $order_id);
        if ($stmt->execute()) {
            json_response(['status' => 'success', 'message' => 'Order status updated.']);
        } else {
            json_response(['status' => 'error', 'message' => 'Failed to update status.'], 500);
        }
    } else {
        json_response(['status' => 'error', 'message' => 'Invalid data provided.'], 400);
    }
    exit;
}

$order_id = (int)($_GET['id'] ?? 0);
if ($order_id <= 0) {
    header('Location: order.php');
    exit;
}

// Fetch order details
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: order.php');
    exit;
}

// Fetch order items
$order_items = [];
$stmt = $conn->prepare("SELECT oi.*, p.name as product_name, p.image as product_image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $order_items[] = $row;
}

include 'common/header.php';
?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Order Items -->
    <div class="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-bold mb-4">Order #<?= $order['id'] ?> Items</h2>
        <div class="space-y-4">
            <?php foreach ($order_items as $item): ?>
            <div class="flex items-center space-x-4 border-b pb-4 last:border-b-0 last:pb-0">
                <img src="../uploads/<?= htmlspecialchars($item['product_image']) ?>" class="w-16 h-16 rounded-md object-cover">
                <div class="flex-grow">
                    <p class="font-semibold"><?= htmlspecialchars($item['product_name']) ?></p>
                    <!-- FIX: Changed format_rupee to format_taka -->
                    <p class="text-sm text-slate-500">Qty: <?= $item['quantity'] ?> x <?= format_taka($item['price']) ?></p>
                </div>
                <!-- FIX: Changed format_rupee to format_taka -->
                <p class="font-semibold"><?= format_taka($item['quantity'] * $item['price']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="flex justify-end mt-4 pt-4 border-t text-lg">
            <span class="font-semibold mr-4">Total:</span>
            <!-- FIX: Changed format_rupee to format_taka -->
            <span class="font-bold text-indigo-600"><?= format_taka($order['total_amount']) ?></span>
        </div>
    </div>

    <!-- Right Column -->
    <div class="space-y-6">
        <!-- Customer Details -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">Customer Details</h2>
            <p><strong>Name:</strong> <?= htmlspecialchars($order['first_name'] . ' ' . $order['last_name']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?></p>
            <p class="mt-2"><strong>Address:</strong><br><?= nl2br(htmlspecialchars($order['address_line'] . ", " . $order['upazila'] . ", " . $order['city'] . ", " . $order['division'])) ?></p>
        </div>

        <!-- Payment Details -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">Payment Details</h2>
            <p><strong>Method:</strong> <span class="font-semibold text-indigo-600"><?= htmlspecialchars($order['payment_method']) ?></span></p>
            <?php if (in_array($order['payment_method'], ['Bkash', 'Nagad'])): ?>
                <div class="mt-3 pt-3 border-t">
                    <p><strong>Sender No:</strong> <?= htmlspecialchars($order['sender_number']) ?></p>
                    <p><strong>TrxID:</strong> <?= htmlspecialchars($order['transaction_id']) ?></p>
                    <?php if (!empty($order['payment_screenshot'])): ?>
                        <p class="mt-2"><strong>Screenshot:</strong> 
                            <a href="../uploads/<?= htmlspecialchars($order['payment_screenshot']) ?>" target="_blank" class="text-blue-600 hover:underline">View Image</a>
                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Update Status -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">Update Status</h2>
            <form id="status-form">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="order_id" value="<?= $order_id ?>">
                <select name="status" id="status-select" class="w-full p-2 border rounded-md">
                    <?php foreach(['Placed', 'Dispatched', 'Delivered', 'Cancelled'] as $s): ?>
                    <option value="<?= $s ?>" <?= $order['status'] == $s ? 'selected' : '' ?>><?= $s ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="w-full mt-4 bg-indigo-600 text-white font-bold py-2 rounded-lg hover:bg-indigo-700">Update</button>
            </form>
        </div>
    </div>
</div>
<script>
document.getElementById('status-form').addEventListener('submit', async e => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const response = await ajaxRequest('order_detail.php', { method: 'POST', body: formData });
    if(response && response.status === 'success') {
        showToast(response.message);
        setTimeout(() => location.reload(), 1500);
    } else if(response) {
        showToast(response.message, 'error');
    }
});
</script>
<?php
$conn->close();
include 'common/bottom.php';
?>