<?php
require_once '../common/config.php';
require_admin_login();

// Fetch stats
$total_users = $conn->query("SELECT COUNT(id) as count FROM users")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(id) as count FROM orders")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(total_amount) as sum FROM orders WHERE status = 'Delivered'")->fetch_assoc()['sum'] ?? 0;
$active_products = $conn->query("SELECT COUNT(id) as count FROM products WHERE stock > 0")->fetch_assoc()['count'];
$pending_orders = $conn->query("SELECT COUNT(id) as count FROM orders WHERE status = 'Placed'")->fetch_assoc()['count'];
$cancelled_orders = $conn->query("SELECT COUNT(id) as count FROM orders WHERE status = 'Cancelled'")->fetch_assoc()['count'];

$stats = [
    // FIX: Changed format_rupee to format_taka
    ['label' => 'Total Revenue', 'value' => format_taka($total_revenue), 'icon' => 'fa-dollar-sign', 'color' => 'bg-green-500'],
    ['label' => 'Total Orders', 'value' => $total_orders, 'icon' => 'fa-box-open', 'color' => 'bg-blue-500'],
    ['label' => 'Total Users', 'value' => $total_users, 'icon' => 'fa-users', 'color' => 'bg-indigo-500'],
    ['label' => 'Active Products', 'value' => $active_products, 'icon' => 'fa-shopping-bag', 'color' => 'bg-purple-500'],
    ['label' => 'Pending Shipments', 'value' => $pending_orders, 'icon' => 'fa-shipping-fast', 'color' => 'bg-yellow-500'],
    ['label' => 'Cancellations', 'value' => $cancelled_orders, 'icon' => 'fa-times-circle', 'color' => 'bg-red-500'],
];

// Fetch recent orders
$recent_orders = [];
$result = $conn->query("SELECT o.id, u.name as user_name, o.total_amount, o.status, o.created_at FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");
if($result) {
    while($row = $result->fetch_assoc()){
        $recent_orders[] = $row;
    }
}

include 'common/header.php';
?>
<!-- Stats Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php foreach ($stats as $stat): ?>
    <div class="bg-white rounded-lg shadow-lg p-5 flex items-center space-x-4 transform hover:-translate-y-1 transition-transform">
        <div class="flex-shrink-0 w-12 h-12 <?= $stat['color'] ?> text-white rounded-full flex items-center justify-center">
            <i class="fas <?= $stat['icon'] ?> text-xl"></i>
        </div>
        <div>
            <p class="text-sm font-medium text-slate-500"><?= $stat['label'] ?></p>
            <p class="text-2xl font-bold text-slate-800"><?= $stat['value'] ?></p>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Quick Actions & Recent Orders -->
<div class="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Recent Orders -->
    <div class="lg:col-span-2 bg-white rounded-lg shadow-lg p-5">
        <h2 class="text-lg font-semibold text-slate-800 mb-4">Recent Orders</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-slate-500">
                <thead class="text-xs text-slate-700 uppercase bg-slate-50">
                    <tr>
                        <th class="px-4 py-3">Order ID</th>
                        <th class="px-4 py-3">Customer</th>
                        <th class="px-4 py-3">Amount</th>
                        <th class="px-4 py-3">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($recent_orders)): ?>
                    <?php foreach($recent_orders as $order): ?>
                    <tr class="bg-white border-b hover:bg-slate-50">
                        <td class="px-4 py-3 font-medium text-slate-900">#<?= $order['id'] ?></td>
                        <td class="px-4 py-3"><?= htmlspecialchars($order['user_name']) ?></td>
                        <!-- FIX: Changed format_rupee to format_taka -->
                        <td class="px-4 py-3"><?= format_taka($order['total_amount']) ?></td>
                        <td class="px-4 py-3">
                            <span class="px-2 py-1 font-semibold leading-tight rounded-full text-xs
                                <?= $order['status'] == 'Delivered' ? 'bg-green-100 text-green-700' : '' ?>
                                <?= $order['status'] == 'Placed' ? 'bg-blue-100 text-blue-700' : '' ?>
                                <?= $order['status'] == 'Dispatched' ? 'bg-yellow-100 text-yellow-700' : '' ?>
                                <?= $order['status'] == 'Cancelled' ? 'bg-red-100 text-red-700' : '' ?>
                            ">
                                <?= $order['status'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <tr><td colspan="4" class="text-center py-4">No recent orders.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="bg-white rounded-lg shadow-lg p-5">
        <h2 class="text-lg font-semibold text-slate-800 mb-4">Quick Actions</h2>
        <div class="space-y-3">
            <a href="product.php" class="flex items-center w-full p-3 bg-indigo-50 text-indigo-700 rounded-lg hover:bg-indigo-100 transition-colors">
                <i class="fas fa-plus-circle mr-3"></i> Add New Product
            </a>
            <a href="category.php" class="flex items-center w-full p-3 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors">
                <i class="fas fa-tags mr-3"></i> Manage Categories
            </a>
            <a href="order.php" class="flex items-center w-full p-3 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors">
                <i class="fas fa-box-open mr-3"></i> View All Orders
            </a>
            <a href="user.php" class="flex items-center w-full p-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors">
                <i class="fas fa-users-cog mr-3"></i> Manage Users
            </a>
        </div>
    </div>
</div>
<?php
$conn->close();
include 'common/bottom.php';
?>