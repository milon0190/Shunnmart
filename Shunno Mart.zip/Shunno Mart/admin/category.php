<?php
require_once '../common/config.php';
require_admin_login();

// Handle AJAX requests for CRUD
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'create' || $action === 'update') {
        $name = trim($_POST['name'] ?? '');
        $id = (int)($_POST['id'] ?? 0);
        $image_name = $_POST['existing_image'] ?? '';

        if (empty($name)) {
            json_response(['status' => 'error', 'message' => 'Category name is required.'], 400);
        }

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "../uploads/";
            $image_name = time() . '_' . basename($_FILES["image"]["name"]);
            $target_file = $target_dir . $image_name;
            if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                json_response(['status' => 'error', 'message' => 'Failed to upload image.'], 500);
            }
        }

        if ($action === 'create') {
            $stmt = $conn->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
            $stmt->bind_param("ss", $name, $image_name);
        } else { // update
            $stmt = $conn->prepare("UPDATE categories SET name = ?, image = ? WHERE id = ?");
            $stmt->bind_param("ssi", $name, $image_name, $id);
        }

        if ($stmt->execute()) {
            json_response(['status' => 'success', 'message' => 'Category saved successfully.']);
        } else {
            json_response(['status' => 'error', 'message' => 'Failed to save category.'], 500);
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        // Optional: Delete image file from server
        $stmt_img = $conn->prepare("SELECT image FROM categories WHERE id = ?");
        $stmt_img->bind_param("i", $id);
        $stmt_img->execute();
        $img_res = $stmt_img->get_result()->fetch_assoc();
        if($img_res && !empty($img_res['image'])) {
            @unlink('../uploads/' . $img_res['image']);
        }

        $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            json_response(['status' => 'success', 'message' => 'Category deleted.']);
        } else {
            json_response(['status' => 'error', 'message' => 'Failed to delete category.'], 500);
        }
    }
    exit;
}

// Fetch all categories
$categories = [];
$result = $conn->query("SELECT * FROM categories ORDER BY name ASC");
if($result) {
    while($row = $result->fetch_assoc()){
        $categories[] = $row;
    }
}

include 'common/header.php';
?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Manage Categories</h1>
    <button id="add-category-btn" class="bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
        <i class="fas fa-plus mr-2"></i>Add Category
    </button>
</div>

<!-- Categories Table -->
<div class="bg-white rounded-lg shadow-md overflow-hidden">
    <table class="w-full text-sm text-left text-slate-500">
        <thead class="text-xs text-slate-700 uppercase bg-slate-50">
            <tr>
                <th class="px-6 py-3">Image</th>
                <th class="px-6 py-3">Name</th>
                <th class="px-6 py-3 text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($categories as $cat): ?>
            <tr class="bg-white border-b hover:bg-slate-50" id="cat-row-<?= $cat['id'] ?>">
                <td class="px-6 py-4">
                    <img src="../uploads/<?= htmlspecialchars($cat['image']) ?>" alt="" class="h-10 w-10 object-cover rounded-md">
                </td>
                <td class="px-6 py-4 font-medium text-slate-900"><?= htmlspecialchars($cat['name']) ?></td>
                <td class="px-6 py-4 text-right">
                    <button class="edit-btn text-blue-600 hover:text-blue-900 mr-2" data-id="<?= $cat['id'] ?>" data-name="<?= htmlspecialchars($cat['name']) ?>" data-image="<?= htmlspecialchars($cat['image']) ?>">Edit</button>
                    <button class="delete-btn text-red-600 hover:text-red-900" data-id="<?= $cat['id'] ?>">Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Add/Edit Category Modal -->
<div id="category-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
        <h2 id="modal-title" class="text-xl font-bold mb-4">Add Category</h2>
        <form id="category-form">
            <input type="hidden" name="action" id="modal-action">
            <input type="hidden" name="id" id="modal-id">
            <input type="hidden" name="existing_image" id="existing-image">
            <div class="mb-4">
                <label for="name" class="block text-sm font-medium text-slate-600">Category Name</label>
                <input type="text" name="name" id="modal-name" class="mt-1 block w-full input-style" required>
            </div>
            <div class="mb-4">
                <label for="image" class="block text-sm font-medium text-slate-600">Image</label>
                <input type="file" name="image" id="modal-image" class="mt-1 block w-full text-sm">
                <img id="image-preview" src="#" alt="Image Preview" class="mt-2 h-20 hidden">
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" id="cancel-btn" class="bg-slate-200 text-slate-800 py-2 px-4 rounded-lg">Cancel</button>
                <button type="submit" class="bg-indigo-600 text-white py-2 px-4 rounded-lg">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('category-modal');
    const addBtn = document.getElementById('add-category-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const form = document.getElementById('category-form');
    
    function showModal(title, action, data = {}) {
        document.getElementById('modal-title').innerText = title;
        document.getElementById('modal-action').value = action;
        document.getElementById('modal-id').value = data.id || '';
        document.getElementById('modal-name').value = data.name || '';
        document.getElementById('existing-image').value = data.image || '';
        
        const preview = document.getElementById('image-preview');
        if (data.image) {
            preview.src = '../uploads/' + data.image;
            preview.classList.remove('hidden');
        } else {
            preview.classList.add('hidden');
        }
        
        modal.classList.remove('hidden');
    }

    function hideModal() {
        modal.classList.add('hidden');
        form.reset();
        document.getElementById('image-preview').classList.add('hidden');
    }

    addBtn.addEventListener('click', () => showModal('Add Category', 'create'));
    cancelBtn.addEventListener('click', hideModal);

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const data = {
                id: btn.dataset.id,
                name: btn.dataset.name,
                image: btn.dataset.image
            };
            showModal('Edit Category', 'update', data);
        });
    });

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const formData = new FormData(form);
        const response = await ajaxRequest('category.php', { method: 'POST', body: formData });
        if (response && response.status === 'success') {
            showToast(response.message);
            hideModal();
            location.reload(); // Simple refresh to show changes
        } else if (response) {
            showToast(response.message, 'error');
        }
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to delete this category? This will also delete all products under it.')) return;
            
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('id', btn.dataset.id);
            
            const response = await ajaxRequest('category.php', { method: 'POST', body: formData });
            if (response && response.status === 'success') {
                showToast(response.message);
                document.getElementById('cat-row-' + btn.dataset.id).remove();
            } else if (response) {
                showToast(response.message, 'error');
            }
        });
    });
});
</script>
<style>.input-style{padding:.5rem .75rem;border:1px solid #cbd5e1;border-radius:.375rem}.input-style:focus{outline:none;border-color:#6366f1;box-shadow:0 0 0 1px #6366f1}</style>
<?php
$conn->close();
include 'common/bottom.php';
?>