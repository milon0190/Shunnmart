<?php
// admin/product.php

// Always start with the config file to load functions and DB connection.
require_once __DIR__ . '/../common/config.php';
require_admin_login();

// --- Handle AJAX requests for product CRUD ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // This part is for creating, updating, or deleting products via AJAX.
    // It's assumed to be correct for now. The error is in the display part.
    $action = $_POST['action'];

    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $cat_id = (int)($_POST['cat_id'] ?? 0);
        $description = trim($_POST['description'] ?? '');
        $price = (float)($_POST['price'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        $image_name = $_POST['existing_image'] ?? '';

        if (empty($name) || $cat_id <= 0 || $price <= 0) {
            json_response(['status' => 'error', 'message' => 'Name, Category, and Price are required.'], 400);
        }

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "../uploads/";
            $image_name = time() . '_prod_' . basename($_FILES["image"]["name"]);
            $target_file = $target_dir . $image_name;
            if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                json_response(['status' => 'error', 'message' => 'Failed to upload image.'], 500);
            }
        }

        if ($action === 'create') {
            $stmt = $conn->prepare("INSERT INTO products (name, cat_id, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sisdis", $name, $cat_id, $description, $price, $stock, $image_name);
        } else { // update
            $stmt = $conn->prepare("UPDATE products SET name=?, cat_id=?, description=?, price=?, stock=?, image=? WHERE id=?");
            $stmt->bind_param("sisdisi", $name, $cat_id, $description, $price, $stock, $image_name, $id);
        }

        if ($stmt->execute()) { json_response(['status' => 'success', 'message' => 'Product saved successfully.']); } 
        else { json_response(['status' => 'error', 'message' => 'Failed to save product.'], 500); }
    }
    
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) { json_response(['status' => 'success', 'message' => 'Product deleted.']); } 
        else { json_response(['status' => 'error', 'message' => 'Failed to delete product.'], 500); }
    }
    exit;
}

// --- Fetch data for displaying on the page ---
$products = [];
$categories = [];

if ($conn && !$conn->connect_error) {
    // Fetch all products with their category names
    $prod_result = $conn->query("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.cat_id = c.id ORDER BY p.created_at DESC");
    if ($prod_result) {
        while($row = $prod_result->fetch_assoc()) {
            $products[] = $row;
        }
    }

    // Fetch all categories for the add/edit modal dropdown
    $cat_result = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
    if ($cat_result) {
        while($row = $cat_result->fetch_assoc()){
            $categories[] = $row;
        }
    }
}

// Include HTML header
include 'common/header.php';
?>

<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Manage Products</h1>
    <button id="add-product-btn" class="bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700">
        <i class="fas fa-plus mr-2"></i>Add Product
    </button>
</div>

<!-- Products Table -->
<div class="bg-white rounded-lg shadow-md overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="text-xs text-slate-700 uppercase bg-slate-50">
            <tr>
                <th class="p-3">Image</th>
                <th class="p-3">Name</th>
                <th class="p-3">Category</th>
                <th class="p-3">Price</th>
                <th class="p-3">Stock</th>
                <th class="p-3 text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($products as $prod): ?>
            <tr class="border-b hover:bg-slate-50">
                <td class="p-3"><img src="../uploads/<?= htmlspecialchars($prod['image']) ?>" class="h-12 w-12 object-cover rounded-md"></td>
                <td class="p-3 font-medium text-slate-900"><?= htmlspecialchars($prod['name']) ?></td>
                <td class="p-3"><?= htmlspecialchars($prod['category_name']) ?></td>
                <!-- FIX: Changed format_rupee() to format_taka() -->
                <td class="p-3"><?= format_taka($prod['price']) ?></td>
                <td class="p-3"><?= $prod['stock'] ?></td>
                <td class="p-3 text-right whitespace-nowrap">
                    <button class="edit-btn text-blue-600 hover:text-blue-900 mr-2" data-product='<?= json_encode($prod) ?>'>Edit</button>
                    <button class="delete-btn text-red-600 hover:text-red-900" data-id="<?= $prod['id'] ?>">Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Add/Edit Product Modal -->
<div id="product-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
    <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg max-h-screen overflow-y-auto">
        <h2 id="modal-title" class="text-xl font-bold mb-4">Add Product</h2>
        <form id="product-form" class="space-y-4">
            <input type="hidden" name="action" id="modal-action">
            <input type="hidden" name="id" id="modal-id">
            <input type="hidden" name="existing_image" id="existing-image">
            
            <div>
                <label class="block text-sm font-medium">Name</label>
                <input type="text" name="name" id="modal-name" class="mt-1 block w-full input-style" required>
            </div>
            <div>
                <label class="block text-sm font-medium">Category</label>
                <select name="cat_id" id="modal-cat_id" class="mt-1 block w-full input-style" required>
                    <option value="">Select Category</option>
                    <?php foreach($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium">Description</label>
                <textarea name="description" id="modal-description" rows="4" class="mt-1 block w-full input-style"></textarea>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium">Price (৳)</label>
                    <input type="number" name="price" id="modal-price" step="0.01" class="mt-1 block w-full input-style" required>
                </div>
                <div>
                    <label class="block text-sm font-medium">Stock</label>
                    <input type="number" name="stock" id="modal-stock" class="mt-1 block w-full input-style" required>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium">Image</label>
                <input type="file" name="image" id="modal-image" class="mt-1 block w-full text-sm">
                 <img id="image-preview" src="#" alt="Image Preview" class="mt-2 h-20 hidden">
            </div>
            <div class="flex justify-end space-x-2">
                <button type="button" id="cancel-btn" class="bg-slate-200 py-2 px-4 rounded-lg">Cancel</button>
                <button type="submit" class="bg-indigo-600 text-white py-2 px-4 rounded-lg">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
// This JS is for the add/edit modal functionality. It should be correct.
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('product-modal');
    const form = document.getElementById('product-form');

    function showModal(title, action, data = {}) {
        form.reset();
        modal.classList.remove('hidden');
        document.getElementById('modal-title').innerText = title;
        document.getElementById('modal-action').value = action;
        
        if (data.id) {
            document.getElementById('modal-id').value = data.id;
            document.getElementById('modal-name').value = data.name;
            document.getElementById('modal-cat_id').value = data.cat_id;
            document.getElementById('modal-description').value = data.description;
            document.getElementById('modal-price').value = data.price;
            document.getElementById('modal-stock').value = data.stock;
            document.getElementById('existing-image').value = data.image || '';
            const preview = document.getElementById('image-preview');
            if (data.image) {
                preview.src = '../uploads/' + data.image;
                preview.classList.remove('hidden');
            }
        }
    }

    function hideModal() {
        modal.classList.add('hidden');
        document.getElementById('image-preview').classList.add('hidden');
    }

    document.getElementById('add-product-btn').addEventListener('click', () => showModal('Add Product', 'create'));
    document.getElementById('cancel-btn').addEventListener('click', hideModal);

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const productData = JSON.parse(btn.dataset.product);
            showModal('Edit Product', 'update', productData);
        });
    });

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const formData = new FormData(form);
        const response = await ajaxRequest('product.php', { method: 'POST', body: formData });
        if (response && response.status === 'success') {
            showToast(response.message);
            hideModal();
            location.reload();
        } else if (response) {
            showToast(response.message, 'error');
        }
    });

     document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to delete this product?')) return;
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('id', btn.dataset.id);
            const response = await ajaxRequest('product.php', { method: 'POST', body: formData });
            if (response && response.status === 'success') {
                showToast(response.message);
                location.reload();
            } else if (response) {
                showToast(response.message, 'error');
            }
        });
    });
});
</script>
<style>.input-style{padding:.5rem .75rem;border:1px solid #cbd5e1;border-radius:.375rem}.input-style:focus{outline:none;border-color:#6366f1;box-shadow:0 0 0 1px #6366f1}</style>
<?php
if ($conn) { $conn->close(); }
include 'common/bottom.php';
?>