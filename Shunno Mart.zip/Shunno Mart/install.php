<?php
// install.php (Updated Snippet)

// Find the CREATE TABLE `orders` query and replace it with this:
            "CREATE TABLE IF NOT EXISTS `orders` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `user_id` int(11) NOT NULL,
              `first_name` varchar(50) NOT NULL,
              `last_name` varchar(50) NOT NULL,
              `email` varchar(100) NOT NULL,
              `phone` varchar(20) NOT NULL,
              `address_line` text NOT NULL,
              `division` varchar(50) NOT NULL,
              `city` varchar(50) NOT NULL,
              `upazila` varchar(50) NOT NULL,
              `total_amount` decimal(10,2) NOT NULL,
              `payment_method` varchar(50) NOT NULL,
              `sender_number` varchar(20) DEFAULT NULL,
              `transaction_id` varchar(50) DEFAULT NULL,
              `payment_screenshot` varchar(255) DEFAULT NULL,
              `status` enum('Placed','Dispatched','Delivered','Cancelled') NOT NULL DEFAULT 'Placed',
              `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
              PRIMARY KEY (`id`),
              KEY `user_id` (`user_id`),
              CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

// The rest of the file remains the same.
// Just replace the old 'orders' table creation SQL with this new one.
?>