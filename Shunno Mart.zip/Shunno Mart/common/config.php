<?php
// config.php
session_start();

// --- DATABASE CONFIGURATION ---
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'shunno_mart_db');

// --- SITE CONFIGURATION ---
define('BASE_URL', 'http://localhost/shunno-mart');

// --- ESTABLISH DATABASE CONNECTION ---
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- HELPER FUNCTIONS ---

/**
 * Formats a number as Bangladeshi Taka.
 * @param float $number The number to format.
 * @return string The formatted currency string.
 */
function format_taka($number) {
    return '৳ ' . number_format($number, 2);
}

/**
 * Sends a JSON response and exits the script.
 * @param array $data The data to encode as JSON.
 * @param int $statusCode The HTTP status code to send.
 */
function json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Checks if a user is logged in. Redirects to login page if not.
 */
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Checks if an admin is logged in. Redirects to admin login page if not.
 */
function require_admin_login() {
    if (!isset($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
}