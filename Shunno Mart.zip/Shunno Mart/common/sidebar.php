<?php
// sidebar.php

// Do NOT create a new connection. Use the one provided by the page that includes this file.
// The including page (e.g., index.php, checkout.php) is responsible for opening the connection.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$is_logged_in = isset($_SESSION['user_id']);

$nested_categories = [];

// Use the global $conn variable, which should be available from config.php
// Also check if it's a valid object before using it.
if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
    $result = $conn->query("SELECT id, parent_id, name, icon FROM categories ORDER BY name ASC");
    
    if ($result) {
        $all_cats = [];
        while ($cat = $result->fetch_assoc()) {
            $all_cats[$cat['id']] = $cat;
        }

        foreach ($all_cats as $cat) {
            if ($cat['parent_id'] == NULL) {
                $nested_categories[$cat['id']] = $cat;
                $nested_categories[$cat['id']]['subcategories'] = [];
            }
        }
        foreach ($all_cats as $cat) {
            if ($cat['parent_id'] != NULL && isset($nested_categories[$cat['parent_id']])) {
                $nested_categories[$cat['parent_id']]['subcategories'][] = $cat;
            }
        }
    }
}
?>
<!-- Sidebar Overlay -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 hidden"></div>

<!-- Sidebar HTML -->
<aside id="sidebar" class="fixed top-0 left-0 h-full w-72 bg-white shadow-lg z-50 transform -translate-x-full transition-transform duration-300 ease-in-out flex flex-col">
    <div class="p-4 flex items-center justify-between border-b">
        <a href="index.php" class="text-2xl font-bold text-indigo-600">Shunno Mart</a>
        <button id="close-sidebar" class="text-xl text-slate-600"><i class="fas fa-times"></i></button>
    </div>
    
    <nav class="flex-grow overflow-y-auto">
        <div class="p-4">
            <h3 class="font-semibold text-slate-500 text-sm mb-2 uppercase">Categories</h3>
            <ul class="space-y-1">
                <?php if (!empty($nested_categories)): ?>
                    <?php foreach ($nested_categories as $main_cat): ?>
                    <li>
                        <button class="w-full flex items-center justify-between p-2 text-slate-700 hover:bg-slate-100 rounded-md category-toggle">
                            <span class="flex items-center">
                                <i class="fas <?= htmlspecialchars($main_cat['icon'] ?? 'fa-tag') ?> w-6 text-center text-indigo-500"></i>
                                <span class="ml-3"><?= htmlspecialchars($main_cat['name']) ?></span>
                            </span>
                            <?php if (!empty($main_cat['subcategories'])): ?>
                                <i class="fas fa-chevron-down transform transition-transform duration-200"></i>
                            <?php endif; ?>
                        </button>
                        <?php if (!empty($main_cat['subcategories'])): ?>
                        <ul class="pl-8 mt-1 space-y-1 hidden">
                            <?php foreach ($main_cat['subcategories'] as $sub_cat): ?>
                            <li><a href="product.php?cat_id=<?= $sub_cat['id'] ?>" class="block p-2 text-sm text-slate-600 hover:bg-slate-100 rounded-md"><?= htmlspecialchars($sub_cat['name']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-slate-500 text-sm p-2">No categories found.</p>
                <?php endif; ?>
            </ul>
        </div>
        <hr class="my-2">
        <div class="p-4">
             <h3 class="font-semibold text-slate-500 text-sm mb-2 uppercase">My Account</h3>
             <a href="order.php" class="flex items-center p-2 text-slate-700 hover:bg-slate-100 rounded-md"><i class="fas fa-box w-6 text-center"></i><span class="ml-3">My Orders</span></a>
             <a href="profile.php" class="flex items-center p-2 text-slate-700 hover:bg-slate-100 rounded-md"><i class="fas fa-user w-6 text-center"></i><span class="ml-3">Profile</span></a>
        </div>
    </nav>
    <div class="p-4 border-t">
        <?php if ($is_logged_in): ?>
            <a href="profile.php?action=logout" class="flex items-center justify-center w-full p-2 text-red-500 bg-red-50 hover:bg-red-100 rounded-md font-semibold"><i class="fas fa-sign-out-alt mr-2"></i>Logout</a>
        <?php else: ?>
            <a href="login.php" class="flex items-center justify-center w-full p-2 text-green-600 bg-green-50 hover:bg-green-100 rounded-md font-semibold"><i class="fas fa-sign-in-alt mr-2"></i>Login / Sign Up</a>
        <?php endif; ?>
    </div>
</aside>
<script>
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.category-toggle').forEach(button => {
        button.addEventListener('click', (e) => {
            const submenu = e.currentTarget.nextElementSibling;
            if (submenu && submenu.tagName === 'UL') {
                const icon = e.currentTarget.querySelector('.fa-chevron-down');
                submenu.classList.toggle('hidden');
                if (icon) icon.classList.toggle('rotate-180');
            }
        });
    });
});
</script>