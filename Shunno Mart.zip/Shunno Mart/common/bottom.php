        <!-- Bottom Navigation -->
        <nav class="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_5px_rgba(0,0,0,0.1)] z-40 flex justify-around p-2">
            <a href="index.php" class="flex flex-col items-center text-slate-600 hover:text-indigo-600 w-1/4">
                <i class="fas fa-home text-xl"></i>
                <span class="text-xs mt-1">Home</span>
            </a>
            <a href="cart.php" class="flex flex-col items-center text-slate-600 hover:text-indigo-600 w-1/4 relative">
                <i class="fas fa-shopping-bag text-xl"></i>
                <span class="text-xs mt-1">Cart</span>
                <?php if ($cart_count > 0): ?>
                    <span class="absolute top-0 right-[25%] bg-red-500 text-white text-[10px] rounded-full h-4 w-4 flex items-center justify-center">
                        <?= $cart_count ?>
                    </span>
                <?php endif; ?>
            </a>
            <a href="order.php" class="flex flex-col items-center text-slate-600 hover:text-indigo-600 w-1/4">
                <i class="fas fa-receipt text-xl"></i>
                <span class="text-xs mt-1">Orders</span>
            </a>
            <a href="profile.php" class="flex flex-col items-center text-slate-600 hover:text-indigo-600 w-1/4">
                <i class="fas fa-user-circle text-xl"></i>
                <span class="text-xs mt-1">Profile</span>
            </a>
        </nav>
    </div> <!-- end main container -->
</body>
</html>