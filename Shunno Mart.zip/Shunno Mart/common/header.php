<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Shunno Mart</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="assets/js/main.js" defer></script>
    <style>
        body { font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        /* For Webkit-based browsers (Chrome, Safari) */
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        /* For IE, Edge, and Firefox */
        .no-scrollbar {
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;  /* Firefox */
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased overflow-x-hidden">
    <!-- Main container -->
    <div class="relative min-h-screen pb-20"> <!-- padding-bottom to avoid overlap with bottom nav -->
        
        <!-- Top Header -->
        <header class="sticky top-0 bg-white shadow-sm z-40 p-3 flex items-center justify-between">
            <button id="open-sidebar" class="text-xl text-slate-600">
                <i class="fas fa-bars"></i>
            </button>
            <a href="index.php" class="text-2xl font-bold text-indigo-600">Shunno Mart</a>
            <a href="cart.php" class="relative text-xl text-slate-600">
                <i class="fas fa-shopping-cart"></i>
                <?php if ($cart_count > 0): ?>
                    <span id="cart-count-badge" class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        <?= $cart_count ?>
                    </span>
                <?php endif; ?>
            </a>
        </header>