<?php
require_once 'common/config.php';

// If user is already logged in, redirect to homepage
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // --- LOGIN ACTION ---
    if ($action === 'login') {
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            json_response(['status' => 'error', 'message' => 'Email and password are required.'], 400);
        }

        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                json_response(['status' => 'success', 'redirect' => 'index.php']);
            } else {
                json_response(['status' => 'error', 'message' => 'Invalid email or password.'], 401);
            }
        } else {
            json_response(['status' => 'error', 'message' => 'Invalid email or password.'], 401);
        }
        $stmt->close();
    }

    // --- SIGNUP ACTION ---
    if ($action === 'signup') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';

        if (empty($name) || empty($phone) || empty($email) || empty($password)) {
            json_response(['status' => 'error', 'message' => 'All fields are required.'], 400);
        }
        if (strlen($password) < 6) {
            json_response(['status' => 'error', 'message' => 'Password must be at least 6 characters.'], 400);
        }

        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            json_response(['status' => 'error', 'message' => 'An account with this email already exists.'], 409);
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)");
            $insert_stmt->bind_param("ssss", $name, $phone, $email, $hashed_password);

            if ($insert_stmt->execute()) {
                $user_id = $insert_stmt->insert_id;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $name;
                json_response(['status' => 'success', 'redirect' => 'index.php']);
            } else {
                json_response(['status' => 'error', 'message' => 'Registration failed. Please try again.'], 500);
            }
            $insert_stmt->close();
        }
        $stmt->close();
    }

    $conn->close();
    exit; // Stop script execution after handling AJAX
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login / Sign Up - Shunno Mart</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="assets/js/main.js" defer></script>
    <style>
        body { font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-slate-100 flex items-center justify-center min-h-screen">

    <div class="w-full max-w-md p-4 sm:p-6">
        <div class="text-center mb-8">
            <a href="index.php" class="text-4xl font-bold text-indigo-600">Shunno Mart</a>
            <p class="text-slate-500 mt-2">Welcome! Please login or create an account.</p>
        </div>

        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <!-- Tabs -->
            <div class="flex">
                <button id="login-tab-btn" class="w-1/2 p-4 font-semibold text-center bg-indigo-600 text-white transition-colors">Login</button>
                <button id="signup-tab-btn" class="w-1/2 p-4 font-semibold text-center bg-white text-slate-600 transition-colors">Sign Up</button>
            </div>

            <!-- Forms -->
            <div class="p-6">
                <!-- Login Form -->
                <form id="login-form">
                    <input type="hidden" name="action" value="login">
                    <div class="space-y-4">
                        <div>
                            <label for="login-email" class="text-sm font-medium text-slate-600">Email</label>
                            <input type="email" id="login-email" name="email" class="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label for="login-password" class="text-sm font-medium text-slate-600">Password</label>
                            <input type="password" id="login-password" name="password" class="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                    </div>
                    <button type="submit" class="w-full mt-6 bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors">Login</button>
                </form>

                <!-- Signup Form -->
                <form id="signup-form" class="hidden">
                    <input type="hidden" name="action" value="signup">
                    <div class="space-y-4">
                        <div>
                            <label for="signup-name" class="text-sm font-medium text-slate-600">Full Name</label>
                            <input type="text" id="signup-name" name="name" class="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                         <div>
                            <label for="signup-phone" class="text-sm font-medium text-slate-600">Phone</label>
                            <input type="tel" id="signup-phone" name="phone" class="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label for="signup-email" class="text-sm font-medium text-slate-600">Email</label>
                            <input type="email" id="signup-email" name="email" class="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                        <div>
                            <label for="signup-password" class="text-sm font-medium text-slate-600">Password</label>
                            <input type="password" id="signup-password" name="password" class="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                        </div>
                    </div>
                    <button type="submit" class="w-full mt-6 bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 transition-colors">Create Account</button>
                </form>
            </div>
        </div>
    </div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const loginTabBtn = document.getElementById('login-tab-btn');
    const signupTabBtn = document.getElementById('signup-tab-btn');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');

    loginTabBtn.addEventListener('click', () => {
        loginForm.classList.remove('hidden');
        signupForm.classList.add('hidden');
        loginTabBtn.classList.add('bg-indigo-600', 'text-white');
        loginTabBtn.classList.remove('bg-white', 'text-slate-600');
        signupTabBtn.classList.add('bg-white', 'text-slate-600');
        signupTabBtn.classList.remove('bg-indigo-600', 'text-white');
    });

    signupTabBtn.addEventListener('click', () => {
        signupForm.classList.remove('hidden');
        loginForm.classList.add('hidden');
        signupTabBtn.classList.add('bg-indigo-600', 'text-white');
        signupTabBtn.classList.remove('bg-white', 'text-slate-600');
        loginTabBtn.classList.add('bg-white', 'text-slate-600');
        loginTabBtn.classList.remove('bg-indigo-600', 'text-white');
    });

    // Login Form Submission
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(loginForm);
        const response = await ajaxRequest('login.php', {
            method: 'POST',
            body: formData
        });

        if (response && response.status === 'success') {
            showToast('Login successful! Redirecting...');
            window.location.href = response.redirect;
        } else if (response) {
            showToast(response.message, 'error');
        }
    });

    // Signup Form Submission
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(signupForm);
        const response = await ajaxRequest('login.php', {
            method: 'POST',
            body: formData
        });

        if (response && response.status === 'success') {
            showToast('Account created! Redirecting...');
            window.location.href = response.redirect;
        } else if (response) {
            showToast(response.message, 'error');
        }
    });
});
</script>
</body>
</html>