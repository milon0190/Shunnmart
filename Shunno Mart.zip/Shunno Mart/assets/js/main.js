// main.js - Global JavaScript for Shunno Mart

document.addEventListener('DOMContentLoaded', () => {

    // --- GLOBAL UX ENHANCEMENTS ---
    // Disable right-click context menu
    document.addEventListener('contextmenu', event => event.preventDefault());

    // Disable text selection
    document.body.style.userSelect = 'none';

    // Disable zoom (for mobile)
    document.addEventListener('touchstart', (event) => {
        if (event.touches.length > 1) {
            event.preventDefault();
        }
    }, { passive: false });

    let lastTouchEnd = 0;
    document.addEventListener('touchend', (event) => {
        const now = (new Date()).getTime();
        if (now - lastTouchEnd <= 300) {
            event.preventDefault();
        }
        lastTouchEnd = now;
    }, false);


    // --- GLOBAL COMPONENTS & HELPERS ---

    // Generic function to toggle visibility of an element
    window.toggleElement = (elementId) => {
        const element = document.getElementById(elementId);
        if (element) {
            element.classList.toggle('hidden');
        }
    };

    // AJAX loader modal
    window.showLoader = () => {
        let loader = document.getElementById('global-loader');
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'global-loader';
            loader.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100]';
            loader.innerHTML = `
                <div class="bg-white p-6 rounded-lg shadow-xl flex items-center space-x-4">
                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
                    <span class="text-lg font-medium text-slate-700">Processing...</span>
                </div>
            `;
            document.body.appendChild(loader);
        }
        loader.classList.remove('hidden');
    };

    window.hideLoader = () => {
        const loader = document.getElementById('global-loader');
        if (loader) {
            loader.classList.add('hidden');
        }
    };
    
    // Toast Notification
    window.showToast = (message, type = 'success') => {
        let toast = document.getElementById('global-toast');
        if (toast) {
            toast.remove();
        }

        toast = document.createElement('div');
        toast.id = 'global-toast';
        
        const bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
        
        toast.className = `fixed top-5 right-5 ${bgColor} text-white py-2 px-4 rounded-lg shadow-lg transform translate-x-full animate-slide-in z-[101]`;
        toast.textContent = message;

        document.body.appendChild(toast);
        
        // Add animation keyframes
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes slide-in {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
            }
            .animate-slide-in {
                animation: slide-in 0.3s forwards;
            }
        `;
        document.head.appendChild(style);


        setTimeout(() => {
            toast.remove();
            style.remove();
        }, 3000);
    };


    // Sidebar toggle logic
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const openSidebarBtn = document.getElementById('open-sidebar');
    const closeSidebarBtn = document.getElementById('close-sidebar');

    const toggleSidebar = () => {
        sidebar.classList.toggle('-translate-x-full');
        sidebarOverlay.classList.toggle('hidden');
    };

    if (openSidebarBtn) openSidebarBtn.addEventListener('click', toggleSidebar);
    if (closeSidebarBtn) closeSidebarBtn.addEventListener('click', toggleSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', toggleSidebar);

});

// A simple fetch wrapper for AJAX calls
async function ajaxRequest(url, options) {
    showLoader();
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('AJAX Error:', error);
        showToast('An error occurred. Please try again.', 'error');
        return null;
    } finally {
        hideLoader();
    }
}